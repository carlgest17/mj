using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using SinadjanApp.Models;
using Microsoft.Extensions.Logging;
using SinadjanApp.Entities;

namespace SinadjanApp.Controllers;


public class MjController : Controller
{

    // private readonly Category _context = new Category();

    // public MjController(Category context)
    // {
    //     _context = context;
    // }

    private readonly ILogger<MjController> _logger;
   private readonly testContext _context;

       public MjController(ILogger<MjController> logger , testContext context)
    {
        _logger = logger;
        _context = context;
    }
    [HttpGet]
    public IActionResult Create()
    {
        return View();
    }

      [HttpPost]
    public IActionResult Create(Category ctg)
    {

        if(ctg == null)
        {

        }else{
          _context.Categories.Add(ctg);
         _context.SaveChanges();
     
        }
        
           return View();

    }
    
     [HttpGet]
    public IActionResult Index()
    {
        return View();
    }


    public IActionResult PersonalInfo()
    {
        ViewData["AGE"] = 21;
        return View();
    }
    public IActionResult EducationalBackground()
    {
        return View();
    }
    public IActionResult Dreamjob()
    {

        return View();
    }
}
