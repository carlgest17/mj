﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using SinadjanApp.Entities;
using SinadjanApp.Models;

namespace SinadjanApp.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;
   private readonly testContext _context;

    public HomeController(ILogger<HomeController> logger , testContext context)
    {
        _logger = logger;
        _context = context;
    }

    public IActionResult Index()

     {

        // Category c = new Category();
        // c.Name = "Hello";
        // _context.Categories.Add(c);
        // _context.SaveChanges();

         person p = new person();
        p.ID = 21;
        p.Fullname = "MICHAEL JAY SINADJAN";

        return View(p);

      


    }

    public IActionResult Privacy()
    {
        person p1 = new person();
        p1.ID = 10;
        p1.Fullname = "MICHAEL JAY SINADJAN";
        p1.AGE = 21;

        person p2 = new person();
        p2.ID = 15;
        p2.Fullname = "JHON MIKO SINADJAN";
        p2.AGE = 10;

        person p3 = new person();
        p3.ID = 20;
        p3.Fullname = "MIGUEL GEVARRU";
        p3.AGE = 54;

        List<person> mj = new List<person>();

        mj.Add(p1);
        mj.Add(p2);
        mj.Add(p3);


        return View(mj);
    }


    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
