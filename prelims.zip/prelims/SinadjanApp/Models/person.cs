namespace SinadjanApp.Models
{
    public class person
    {
        public int ID { get; set; }
        public string Fullname{ get; set; }
        public int AGE { get; set; }
     
    }
}