﻿using System;
using System.Collections.Generic;

namespace SinadjanApp.Entities
{
    public partial class Bangtkok
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
